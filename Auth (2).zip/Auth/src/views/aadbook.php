<?php
    use Carlos\Auth\Models\Book;
    session_start();
    if(!isset($_SESSION['user'])){
        session_destroy();
        header('Location: /');
    }
    if($_SERVER['REQUEST_METHOD']==='POST'&&isset($_POST['title'])){
        $book=new Book($_POST['title']);
        $book->save();
    }
?>
<!DOCTYPE html>
<html lang="en">
    <head>
        <meta charset="UTF-8">
        <meta http-equiv="X-UA-Compatible" content="IE=edge">
        <meta name="viewport" content="width=device-width, initial-scale=1.0">
        <link rel="stylesheet" href="style.css">
        <title>Adicionar livros</title>
    </head>
    <body id="background">
        <div class="all">
            <div class="center">
                <h1 class="title">Usuário: <?php echo ($_SESSION['user']);?></h1>
                <form action="addbook" method="POST" class="form" id="formadd">
                    <input type="text" name="title" placeholder="Título" class="input" id="inadd">
                    <button class="botao2" id="btadd">Adicionar</button>
                </form>
            </div>
        </div>
    </body>
</html>