<!DOCTYPE html>
<html>
	<head>
		<link rel="stylesheet" href="style.css">
		<title>Home</title>
	</head>
	<body id="background">
		<div class="all">
			<div class="center">
				<h1 class="title">Bem vindo(a) à sua biblioteca!</h1>
				<div class="parts">
					<div class="left">
						<form action="/login" method="GET">
						<button class="botao">Login</button>
						</form>
					</div>
					<div class="right">
						<form action="/register" method="GET">					
						<button class="botao">Registrar-se</button>
						</form>
					</div>
				</div>
			</div>
		</div>
	</body>
</html>