<?php
	use Carlos\Auth\Models\User;
	if(isset($_POST['user'],$_POST['password'])&&$_SERVER['REQUEST_METHOD']==='POST'){
		$user=new User($_POST['user'],$_POST['password']);
		if (!User::exists($_POST['user'],$_POST['password'])) {
			$user->save();
			session_start();
			$_SESSION['user']=$_POST['user'];
            $_SESSION['id']=session_id() . $_POST['user'];
			header('Location: /showpage');
		}

	}else if(!($_SERVER['REQUEST_METHOD']==='GET')){
		header('Location: /');
	}
?>

<!DOCTYPE html>
<html lang="en">
	<head>
		<meta charset="UTF-8">
		<meta http-equiv="X-UA-Compatible" content="IE=edge">
		<meta name="viewport" content="width=device-width, initial-scale=1.0">
		<link rel="stylesheet" href="style.css">
		<title>Registrar-se</title>
	</head>
	<body id="background">
		<div class="all">
			<div class="center">
				<h1 class="title">Registre-se</h1>
				<form action="register" method="POST" class="form">
					<input type="text" name="user" placeholder="Usuário" class="input">
					<input type="password" name="password" placeholder="Senha" class="input">
					<button class="botao2">Enviar</button>
				</form>
			</div>
		</div>
	</body>
</html>