<?php

use Carlos\Auth\Models\User;
    if ($_SERVER['REQUEST_METHOD'] === 'POST'&&isset($_POST['user'], $_POST['password'])){
           if(User::exists($_POST['user'], $_POST['password'])){
                session_start();
                $_SESSION['user'] = $_POST['user'];
                $_SESSION['id'] = session_id() . $_POST['user'];
                header("Location: /showpage");
                exit;
           }

    }else if($_SERVER['REQUEST_METHOD'] === 'GET'){

    }else {
        header("Location: /login");
        exit;
    }


?>
<!DOCTYPE html>
<html lang="en">
    <head>
        <meta charset="UTF-8">
        <meta http-equiv="X-UA-Compatible" content="IE=edge">
        <meta name="viewport" content="width=device-width, initial-scale=1.0">
        <link rel="stylesheet" type="text/css" href="style.css">
        <title>Login</title>
    </head>
    <body id="background">
       <div class="all">
            <div class="center">
                <h1 class="title">Login</h1>
                   <form action="login" method="POST" class="form">
                    <input class="input" type="text" name="user" placeholder="Usuário">
                    <input class="input" type="password" name="password" placeholder="Senha">
                    <button class="botao2">Enviar</button>
                    </form>
            </div>
            
            <div>
                <?php
                    /*mostrar users*/
                    use Carlos\Auth\Models\Model;
                    $result=Model::$conexao->query('SELECT * FROM users;');
                    while($row=$result->fetchArray()){
                        echo $row['username']."<br>";
                    }
                ?>
            </div>
       </div>
    </body>
</html>