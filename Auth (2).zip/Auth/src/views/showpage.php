<?php
    session_start();
    if(!isset($_SESSION['user'])){
        session_destroy();
        header('Location: /');
    }
?>
<!DOCTYPE html>
<html lang="en">
    <head>
        <meta charset="UTF-8">
        <meta http-equiv="X-UA-Compatible" content="IE=edge">
        <meta name="viewport" content="width=device-width, initial-scale=1.0">
        <link rel="stylesheet" href="style.css">
        <title>Show Page</title>
    </head>
    <body id="background">
        <div class="all">
            <div class="center">
                <h1 class="title">Olá, <?php echo $_SESSION['user']?></h1>
                <div class="parts">
                    <div class="left">
                        <form action="addbook" method="GET">
                            <button class="botao">Adicionar livros</button>
                        </form>
                    </div>
                    <div class="right">
                        <form action="lendbook" method="GET">
                            <button class="botao">Empréstimo de livros</button>
                        </form>
                    </div>
                </div>
            </div>
        </div>
    </body>
</html>